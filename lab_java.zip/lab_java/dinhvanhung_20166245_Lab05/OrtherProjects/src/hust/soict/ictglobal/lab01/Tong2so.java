package hust.soict.ictglobal.lab01;

import javax.swing.JOptionPane;
public class Tong2so{
  public static void main(String[] args){
    String strSo1, strSo2;
    String strHienThi = "Tong hai so ";
    
    strSo1 = JOptionPane.showInputDialog(null,
"Hay nhap so thu 1: ","Nhap so thu nhat", 
JOptionPane.INFORMATION_MESSAGE);
    strHienThi += strSo1 + " va ";
    
    strSo2 = JOptionPane.showInputDialog(null,
"Hay nhap so thu 2: ","Nhap so thu hai", 
JOptionPane.INFORMATION_MESSAGE);
    strHienThi += strSo2;
    int So1, So2, Tong;
    So1= Integer.parseInt(strSo1);
    So2= Integer.parseInt(strSo2);
    Tong= So1 + So2;
    strHienThi += " la " + Tong;
    JOptionPane.showMessageDialog(null,strHienThi, 
"Tong hai so", JOptionPane.INFORMATION_MESSAGE);
    System.exit(0);
  }
}
