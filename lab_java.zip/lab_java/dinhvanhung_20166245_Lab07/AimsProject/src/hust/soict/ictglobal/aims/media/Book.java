package hust.soict.ictglobal.aims.media;

import java.util.ArrayList;
import java.util.List;

public class Book extends Media {
	private List<String> authors = new ArrayList<String>();
	public Book() {
		// TODO Auto-generated constructor stub
	}
	public Book(String title) {
		super(title);
	}
	public Book(String title, String category) {
		super(title, category);
	}
	public Book(String title, String category, List<String> authors) {
		super(title, category);
		this.authors = authors;
	}
	public List<String> getAuthors() {
		return authors;
	}
	public void setAuthors(List<String> authors) {
		this.authors = authors;
	}
	
	public void addAuthor(String authorName) {
		int ktra =0;
		for(String x : authors) {
			if(x.equals(authorName)==true) {
				ktra=1;
				break;
			}
		}
		if(ktra==0) {
			authors.add(authorName);
		}
	}
	public void removeAuthor(String authorName) {
		int ktra=0;
		for(String x : authors) {
			if(x.equals(authorName)) {
				ktra=1;
				break;
			}
		}
		if(ktra==1) {
			authors.remove(authorName);
		}
	}

}
