package hust.soict.ictglobal.aims.media;

import java.util.ArrayList;
import hust.soict.ictglobal.aims.media.Playable;

public class CompactDisc extends Disc implements Playable, Comparable<CompactDisc> {
	private String artist;
	private int length;
	private ArrayList<Track> tracks = new ArrayList<Track>();
	
	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public CompactDisc() {
		// TODO Auto-generated constructor stub
	}
	
	public void addTrack(Track track) {
		tracks.add(track);
	}
	public void removeTrack(Track track) {
		tracks.remove(track);
	}
	
	public int getLength() {
		int totalLength=0;
		for(Track x: tracks) {
			totalLength = totalLength + x.getLength();
		}
		return totalLength;
	}
	
	public void play() {
		for(Track x : tracks) {
			x.play();
		}
	}
	
	@Override
	public int compareTo(CompactDisc cd) {
		return this.getTitle().compareTo(cd.getTitle());
	}
}
