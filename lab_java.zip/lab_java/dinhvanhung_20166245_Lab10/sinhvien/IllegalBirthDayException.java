package hust.soict.ictglobal.sinhvien;

public class IllegalBirthDayException extends Exception {

	public IllegalBirthDayException() {
		// TODO Auto-generated constructor stub
	}

	public IllegalBirthDayException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public IllegalBirthDayException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public IllegalBirthDayException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public IllegalBirthDayException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
