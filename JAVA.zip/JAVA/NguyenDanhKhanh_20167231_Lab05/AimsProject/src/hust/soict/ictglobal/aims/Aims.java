package hust.soict.ictglobal.aims;

import hust.soict.ictglobal.aims.disc.DigitalVideoDisc;
import hust.soict.ictglobal.aims.order.Order;;

public class Aims {

	public static void main(String[] args) {
		
		Order anOrder = new Order("2019-03-02");
		DigitalVideoDisc dvd1 = new DigitalVideoDisc("The Lion King");
		dvd1.setCategory("Animation");
		dvd1.setCost(19.95f);
		dvd1.setDirector("Roger Allers");
		dvd1.setLength(87);
		anOrder.addDigitalVideoDisc(dvd1);
		
		DigitalVideoDisc dvd2 = new DigitalVideoDisc("Star Wars");
		dvd2.setCategory("Science Fiction");
		dvd2.setCost(24.95f);
		dvd2.setDirector("George Lucas");
		dvd2.setLength(124);
		anOrder.addDigitalVideoDisc(dvd2);
		
		DigitalVideoDisc dvd3 = new DigitalVideoDisc("Aladdin");
		dvd3.setCategory("Animation");
		dvd3.setCost(18.99f);
		dvd3.setDirector("John Musker");
		dvd3.setLength(90);
		anOrder.addDigitalVideoDisc(dvd3);
		
//		DigitalVideoDisc dvdList[] = new DigitalVideoDisc[10];
//		for(int i=0;i<dvdList.length;i++) {
//			dvdList[i] = dvd1;
//		}
//		anOrder.addDigitalVideoDisc(dvdList);
		
		
		anOrder.addDigitalVideoDisc(dvd1, dvd2);
		anOrder.printListOrdered();
		
		// Tao order moi de test
		Order order2 = new Order("2019-03-03");
		DigitalVideoDisc dvd2_1 = new DigitalVideoDisc("Nguyen's King kaka");
		dvd2_1.setCategory("Animation");
		dvd2_1.setCost(20);
		dvd2_1.setDirector("nguyenvd27");
		dvd2_1.setLength(23);
		order2.addDigitalVideoDisc(dvd2_1);
		order2.printListOrdered();
	}

}