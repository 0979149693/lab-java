package hust.soict.ictglobal.lab02;
import java.util.Scanner;

public class Array{
	public static void main(String[] args){
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Nhap do dai cua mang: ");
		int lenghtArray = keyboard.nextInt();
		int a[] = new int[100];
		int sum=0;
		int i;
		for(i=0;i< lenghtArray; i++){
			System.out.println("a["+i+"]=");
			a[i] = keyboard.nextInt();
			sum= sum+a[i];
		}
		int temp = a[0];
		for( i= 0; i<lenghtArray-1;i++){
			for(int j=i+1; j< lenghtArray; j++){
				if(a[i]>a[j]){
					temp = a[j];
					a[j] = a[i];
					a[i] = temp;
				}
			}
		}
		System.out.println("Mang sau khi sap xep: ");
		for (i = 0; i < lenghtArray; i++) {
            System.out.println(a[i] + " ");
        }

		System.out.println("Sum= "+sum+". Gia tri trung binh= "+ sum/lenghtArray);
	}
}