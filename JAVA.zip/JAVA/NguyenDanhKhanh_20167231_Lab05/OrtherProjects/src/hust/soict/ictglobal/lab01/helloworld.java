package hust.soict.ictglobal.lab01;
public class helloworld {
    public static void main(String[] args){
	System.out.println("Hello, World");
    }
}
