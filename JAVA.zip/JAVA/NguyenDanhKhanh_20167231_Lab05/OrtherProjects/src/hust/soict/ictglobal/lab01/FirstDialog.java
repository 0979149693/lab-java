package hust.soict.ictglobal.lab01;
import javax.swing.JOptionPane;
public class FirstDialog{
	public static void main(String[] args){
		JOptionPane.showMessageDialog(null,"Xin chao ban!");
		System.exit(0);
	}
}
