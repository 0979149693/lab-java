package hust.soict.ictglobal.aims.media;

public class BookTest {

	public static void main(String[] args) {
		Book book = new Book("Tan do crush trong 1 not nhac");
		book.setId("272727");
		//book.setAuthors("nguyenvd27");
		book.addAuthor("nguyenvd27");
		book.setCategory("Tieu Thuyet");
		book.setCost(11111);
		
		book.setContent("day la doan van test class book book book class.day la test test test,nguyenvd,nguyenvd nguyenvd nguyenvd");
		book.processContent();
		System.out.println(book.toString());
	}

}
