package hust.soict.ictglobal.sinhvien;

import java.util.Scanner;

public class Student {

	public static void main(String[] args) {
		SinhVien sv = new SinhVien();
		Scanner scanner = new Scanner(System.in);
		System.out.println("ID: ");
		sv.setId(scanner.nextLine());
		
		System.out.println("Name: ");
		sv.setName(scanner.nextLine());
		
		System.out.println("Birthday(dd/mm/yyyy): ");
		try {
			 sv.setBirthday(scanner.nextLine());
			 sv.checkBirthDay();
		 }
		 catch (IllegalBirthDayException e) {
			 //System.out.println("ERROR BIRTHDAY - FORMAT: dd/mm/yyyy");
			 e.printStackTrace();
		 }
		
		System.out.println("GPA(0-4): ");
		try {
			 sv.setGpa(Float.valueOf(scanner.nextLine()));
			 sv.checkGpa();
		 }
		 catch (IllegalGPAException e) {
			 //System.out.println("ERROR: GPA(float number from 0 to 4)");
			 e.printStackTrace();
		 }
		
		System.out.println(sv.toString());
		
	}

}
