package hust.soict.ictglobal.sinhvien;

public class SinhVien {
	private String id;
	private String name;
	private String birthday;
	private float gpa;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public float getGpa() {
		return gpa;
	}

	public void setGpa(float gpa) {
		this.gpa = gpa;
	}
	
	public SinhVien() {
		// TODO Auto-generated constructor stub
	}
	
	public SinhVien(String id, String name, String birthday, float gpa) {
		super();
		this.id = id;
		this.name = name;
		this.birthday = birthday;
		this.gpa = gpa;
	}
	
	public void checkBirthDay() throws IllegalBirthDayException{
		String[] birthday = this.getBirthday().split("/");
		if(birthday[0].length()!=2 || birthday[1].length()!= 2 || birthday[2].length()!=4 ) {
			System.err.println("ERROR BIRTHDAY - FORMAT: dd/mm/yyyy");
			throw (new IllegalBirthDayException());	
		}
	}
	
	public void checkGpa() throws IllegalGPAException{
		if (this.gpa <=0 || this.gpa >= 4 ) {
			System.err.println("ERROR: GPA(float number from 0 to 4)");
			throw (new IllegalGPAException());
		}
	}
	
	@Override
	public String toString() {
		return "-------students' information----------\n"+
				this.getId()+" - "+this.getName()+" - "+
				this.getBirthday()+" - "+this.getGpa();
	}
}
