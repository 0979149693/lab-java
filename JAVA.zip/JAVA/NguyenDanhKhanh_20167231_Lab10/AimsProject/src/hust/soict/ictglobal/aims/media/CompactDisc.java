package hust.soict.ictglobal.aims.media;

import java.util.ArrayList;

import hust.soict.ictglobal.aims.PlayerException;
import hust.soict.ictglobal.aims.media.Playable;

public class CompactDisc extends Disc implements Playable {
	private String artist;
	private int length;
	private ArrayList<Track> tracks = new ArrayList<Track>();
	
	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public CompactDisc() {
		// TODO Auto-generated constructor stub
	}
	
	public void addTrack(Track track) {
		tracks.add(track);
	}
	public void removeTrack(Track track) {
		tracks.remove(track);
	}
	
	public int getLength() {
		int totalLength=0;
		for(Track x: tracks) {
			totalLength = totalLength + x.getLength();
		}
		return totalLength;
	}
	
	public void play() throws PlayerException {
//		for(Track x : tracks) {
//			x.play();
//		}
		if(this.getLength() <= 0) {
			System.err.println("ERRORimplements Playable, Comparable<DigitalVideoDisc>: CD length is 0");
			throw (new PlayerException());
		}
		
		System.out.println("Playing CD: " + this.getTitle());
		System.out.println("CD length: " + this.getLength());
		
		java.util.Iterator iter = tracks.iterator();
		Track nextTrack;
		
		while(iter.hasNext() ) {
			nextTrack = (Track) iter.next();
			try {
				nextTrack.play();
			} catch (PlayerException e) {
				e.printStackTrace();
			}
		}
	}
	
//	@Override
//	public int compareTo(CompactDisc cd) {
//		return this.getTitle().compareTo(cd.getTitle());
//	}
}
