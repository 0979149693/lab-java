package hust.soict.ictglobal.aims.media;

public abstract class Media implements Comparable<Media>{
	String id;
	String title;
	String category;
	float cost;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public Media() {
		// TODO Auto-generated constructor stub
	}
	public Media(String title){
		this.title = title;
	}

	public Media(String title, String category) {
		this.title = title;
		this.category = category;
	}
	
	@Override
	public boolean equals(Object obj){
		
		if(obj == null) {
			System.err.println("OBJ NULL");
			throw new NullPointerException();
		}
		if(this.getClass() != obj.getClass()) {
			System.err.println("OBJ NOT EQUALS CLASS");
			throw new ClassCastException();
		}
		if (obj instanceof Media) {
			Media media = (Media) obj;
			if(this.getTitle().equals(media.getTitle()) && this.getCost() == media.getCost()) {
				return true;
			}else {
				return false;
			}
			
		}else {
			System.err.println("OBJ NOT INSTANCE OF MEDIA");
			throw new ClassCastException();
		}
	}
	
	@Override
	public int compareTo(Media media) {
		
		if(this.getCost()>media.getCost())
			return 1;
		else if(this.getCost()< media.getCost())
			return -1;
		else
			return 0;
	}

}
