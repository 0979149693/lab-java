
public class DateTest {

	public static void main(String[] args) {
		MyDate date = new MyDate();
		date.accept();
		date.print();
	}

}
